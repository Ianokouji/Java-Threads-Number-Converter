package application;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;



/**
 * Controller class for the JavaFX application.
 */
public class Controller {

	
	//All FXML Fields 
	@FXML
	TextField minText;
	@FXML 
	TextField maxText;
	@FXML
	TextArea BinArea;
	@FXML
	TextArea OctArea;
	@FXML
	TextArea HexArea;
	String MinVal;
	String MaxVal;
	
	
	@FXML
	Button convert;
	
	
	@FXML
	public void convert()
	{
		try {
		    
			// Retrieve the minimum and maximum values from the text fields
		    MinVal = minText.getText();
		    MaxVal = maxText.getText();
		    int minVal = Integer.parseInt(MinVal);
		    int maxVal = Integer.parseInt(MaxVal);

		    if (minVal > maxVal) {
		    	 // Throw an InputMismatchException if the minimum value is greater than the maximum value
		        throw new InputMismatchException("MinVal cannot be greater \nthan MaxVal.");
		    }
		    
		    
		    // Create and start threads for binary, octal, and hexadecimal conversion
		    BinaryThread Binary = new BinaryThread(MinVal,MaxVal,BinArea);
		    Binary.start();
		    OctalThread Octal = new OctalThread(MinVal,MaxVal,OctArea);
		    Octal.start();
		    HexaThread Hexa = new HexaThread(MinVal,MaxVal,HexArea);
		    Hexa.start();
		}
		catch(NumberFormatException e)
		{
			// Handle NumberFormatException for non-integer input
			BinArea.setText("Minimum and Maximum Values \nmust be Integers");
			OctArea.setText("Minimum and Maximum Values \nmust be Integers");
			HexArea.setText("Minimum and Maximum Values \nmust be Integers");
		}
		catch (InputMismatchException e) {
			// Handle InputMismatchException for invalid range
			BinArea.setText("Input mismatch: \n" + e.getMessage());
			OctArea.setText("Input mismatch: \n" + e.getMessage());
			HexArea.setText("Input mismatch: \n" + e.getMessage());
		}
		
	}
}
