package application;

import javafx.scene.control.TextArea;





/**
 * Represents a thread that generates hexadecimal numbers within a given range and displays the output in a TextArea.
 */
public class HexaThread extends Thread {
	private String MinVal;
	private String MaxVal;
	private NewNumber_System Decimal;
	private TextArea OutputText;
	
	
	
	/**
     * Constructs a HexaThread object.
     *
     *  MinVal     The minimum value for the iteration.
     *  MaxVal     The maximum value for the iteration.
     *  OutputText The TextArea where the output will be displayed.
     */
	public HexaThread(String MinVal, String MaxVal, TextArea OutputText)
	{
		this.MinVal = MinVal;
		this.MaxVal = MaxVal;
		this.OutputText = OutputText;
		this.Decimal = new NewNumber_System(10);
	
		
	}
	
	
	/**
     * Executes the thread and generates hexadecimal numbers within the specified range.
     */
	public void run()
	{
		int min = Integer.parseInt(MinVal);
		int max = Integer.parseInt(MaxVal);
		
		
		   StringBuilder TextBuild = new StringBuilder();
		   
		   for (int value = min; value <= max; value++)
		   {
	            String convertedNumber = Decimal.toHexa(Integer.toString(value));
	            System.out.println(convertedNumber);
	            String output = "Hexa value of " + value + ": " + convertedNumber + "\n";
	            TextBuild.append(output);
	            
	         	 	        
		      
		   }
		   // Update the TextArea with the final output
 		   String finalOutput = TextBuild.toString();
 	        OutputText.setText(finalOutput);
		  
		  
	}
}
