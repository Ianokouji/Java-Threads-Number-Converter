package application;
/**
 * Custom exception class for handling input mismatch errors.
 */
public class InputMismatchException extends Exception {
	
	
	 /**
     * Constructs an InputMismatchException with the specified error message.
     *
     * @param message The error message describing the input mismatch.
     */
	 public InputMismatchException(String message) {
	        super(message);
	    }
}
