module PAULMINO_IANGABRIEL_CCC102_ASSIGNMENT5 {
	requires javafx.controls;
	requires javafx.graphics;
	requires javafx.fxml;
	
	opens application to javafx.graphics, javafx.fxml;
}
